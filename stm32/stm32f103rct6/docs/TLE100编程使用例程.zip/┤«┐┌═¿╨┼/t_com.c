#include <AT89X51.h>
#define uchar unsigned  char
#define uint unsigned int
uchar  idata trdata[]={'8','9','S','5','2',0x0d,0x0a,0x00};
uchar  idata trdata1[]={'Y','F','Y',' ','E','l','e','c','t','r','i','o','n','i','e','s',0x0d,0x0a,0x00};
main()
{
uchar i;
  uint j;
SCON= 0x40;                //���ڷ�ʽ1
PCON=0;                     //SMOD=0
REN=1;                     //��������
TMOD= 0x20;                //��ʱ��1��ʱ��ʽ2
TH1= 0xfd;                //11.0592M 9600������
TL1= 0xfd;
TR1= 1;                  //������ʱ��
  while(1)
{
    i=0;
    while(trdata[i]!=0x00)
{
SBUF=trdata[i];
      while(TI==0);
      TI=0;
      i++;
    }
    for (j=0;j<50000;j++); 

	i=0;
	while(trdata1[i]!=0x00)
{
SBUF=trdata1[i];
      while(TI==0);
      TI=0;
      i++;
    }
	 for (j=0;j<50000;j++); 
  }
}
